# FiveThings
#####Five Nature Photos Android App, for Udacity's Android for Beginners Course


###Abhishek Ahuja's Five Pictures App

This app was built using Android Studio v1.3.1 on an Ubuntu 15.10 machine.

You can run this project by importing it in Android Studio and running it on an emulator or Android device.

No additional third-party/external libraries have been used. No new dependencies need to be installed in order to run this application.

I have used a 5-inch Moto G II for testing my app. It will deliver best results on a 5-inch emulator/device. I have not designed the layouts with responsiveness in mind, so they will not render well on other sizes or in landscape mode.
